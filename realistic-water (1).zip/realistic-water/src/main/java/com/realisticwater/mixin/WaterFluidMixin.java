package com.realisticwater.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.WaterFluid;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Perilaku air:
 *  - tick lebih cepat (3 vs 5) => air terasa mengalir lancar, bukan "patah-patah"
 *  - jarak cari lubang lebih jauh (6 vs 4) => air menyebar mengikuti lereng/lubang
 *  - percikan di dasar air terjun
 */
@Mixin(WaterFluid.class)
public abstract class WaterFluidMixin {

	@Inject(method = "getTickRate", at = @At("HEAD"), cancellable = true, require = 0)
	private void rw$tickRate(WorldView world, CallbackInfoReturnable<Integer> cir) {
		cir.setReturnValue(3);
	}

	@Inject(method = "getMaxFlowDistance", at = @At("HEAD"), cancellable = true, require = 0)
	private void rw$flowDistance(WorldView world, CallbackInfoReturnable<Integer> cir) {
		cir.setReturnValue(6);
	}

	@Inject(method = "randomDisplayTick", at = @At("TAIL"), require = 0)
	private void rw$waterfallSplash(World world, BlockPos pos, FluidState state, Random random, CallbackInfo ci) {
		if (state.isStill() || !state.contains(FlowableFluid.FALLING) || !state.get(FlowableFluid.FALLING)) {
			return;
		}
		BlockPos below = pos.down();
		FluidState belowFluid = world.getFluidState(below);
		boolean bottom;
		if (belowFluid.isEmpty()) {
			BlockState bs = world.getBlockState(below);
			bottom = bs.isSolidBlock(world, below);
		} else {
			bottom = belowFluid.isStill()
				|| !belowFluid.contains(FlowableFluid.FALLING)
				|| !belowFluid.get(FlowableFluid.FALLING);
		}
		if (!bottom) {
			return;
		}
		for (int i = 0; i < 3; i++) {
			double x = pos.getX() + random.nextDouble();
			double z = pos.getZ() + random.nextDouble();
			world.addParticle(ParticleTypes.SPLASH, x, pos.getY() + 0.1, z,
				(random.nextDouble() - 0.5) * 0.2, 0.25 + random.nextDouble() * 0.2, (random.nextDouble() - 0.5) * 0.2);
		}
	}
}
