package com.realisticwater.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BucketItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Percikan besar saat air dituang dari ember. */
@Mixin(BucketItem.class)
public abstract class BucketItemMixin {

	@Shadow
	@Final
	private Fluid fluid;

	@Inject(method = "placeFluid", at = @At("RETURN"), require = 0)
	private void rw$pourSplash(@Nullable PlayerEntity player, World world, BlockPos pos,
	                           @Nullable BlockHitResult hit, CallbackInfoReturnable<Boolean> cir) {
		if (!cir.getReturnValueZ() || this.fluid != Fluids.WATER || !(world instanceof ServerWorld sw)) {
			return;
		}
		double x = pos.getX() + 0.5, y = pos.getY() + 0.9, z = pos.getZ() + 0.5;
		sw.spawnParticles(ParticleTypes.SPLASH, x, y, z, 45, 0.35, 0.1, 0.35, 0.35);
		sw.spawnParticles(ParticleTypes.BUBBLE_POP, x, y, z, 12, 0.3, 0.1, 0.3, 0.05);
	}
}
