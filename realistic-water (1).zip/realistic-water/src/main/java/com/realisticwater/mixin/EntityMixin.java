package com.realisticwater.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Percikan lebih besar saat pemain/mob/item masuk air; makin cepat jatuh makin besar. */
@Mixin(Entity.class)
public abstract class EntityMixin {

	@Inject(method = "onSwimmingStart", at = @At("HEAD"), require = 0)
	private void rw$bigSplash(CallbackInfo ci) {
		Entity self = (Entity) (Object) this;
		World world = self.getWorld();
		if (!world.isClient) {
			return;
		}
		Vec3d v = self.getVelocity();
		double speed = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
		int count = MathHelper.clamp((int) (speed * 45.0), 6, 40);
		double w = Math.max(self.getWidth(), 0.4);
		for (int i = 0; i < count; i++) {
			double ox = (world.random.nextDouble() - 0.5) * w * 2.0;
			double oz = (world.random.nextDouble() - 0.5) * w * 2.0;
			world.addParticle(ParticleTypes.SPLASH,
				self.getX() + ox, self.getY() + 0.1, self.getZ() + oz,
				ox * 0.6, 0.2 + world.random.nextDouble() * 0.25 + speed * 0.2, oz * 0.6);
		}
	}
}
