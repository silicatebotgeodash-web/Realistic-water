# Realistic Water (Fabric 1.21.1)

Perilaku air lebih nyata, ringan, tanpa shader:
- Air mengalir lebih cepat dan mencari lubang/lereng lebih jauh
- Percikan besar saat air dituang dari ember
- Percikan saat pemain/mob/item masuk air (makin cepat jatuh makin besar)
- Percikan di dasar air terjun
- Warna air jernih mengikuti biome

Build lewat GitHub Actions (lihat panduan di chat). Butuh Fabric API 0.116.x untuk 1.21.1.
