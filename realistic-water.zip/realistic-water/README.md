# Realistic Water (Fabric 1.21.1)

Mod client-only yang membuat air lebih jernih dan realistis tanpa shader.

- Tekstur air baru 64x64 dengan animasi 32 frame (riak + kaustik), loop mulus
- Air mengalir punya animasi tersendiri
- Warna air dicampur biru-hijau jernih, tapi tetap mengikuti warna biome
- Tidak ada mixin atau shader, jadi performa sama dengan air vanilla

## Build dari HP (lewat GitHub)

1. Buat repo baru di GitHub, lalu upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions**, pilih **Build Realistic Water**, lalu **Run workflow**.
3. Setelah selesai, buka run-nya dan unduh artifact **realistic-water** (zip berisi jar).
4. Ekstrak zip, ambil file `realistic-water-1.0.0.jar` (bukan yang `-sources`).

## Pasang

Taruh jar di folder `mods` bersama **Fabric API 0.116.1+1.21.1** untuk Minecraft 1.21.1
(launcher seperti Zalith / PojavLauncher / FCL mendukung Fabric).
