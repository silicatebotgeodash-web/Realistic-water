package com.realisticwater;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.client.color.world.BiomeColors;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;

/**
 * Realistic Water (client only).
 *
 * Tekstur air (water_still / water_flow) diganti dengan versi beresolusi 64x64
 * yang beranimasi mulus (riak + kaustik) lewat resource di assets/minecraft.
 * Kelas ini hanya mengatur warna: warna biome dicampur dengan biru-hijau jernih
 * supaya air tampak bersih seperti air laut tropis tapi tetap beda tiap biome.
 *
 * Tidak ada mixin, tidak ada shader, tidak ada kerja tambahan per frame,
 * jadi performanya sama dengan air vanilla.
 */
public class RealisticWaterClient implements ClientModInitializer {

	/** Warna air jernih yang dijadikan target campuran (RGB). */
	private static final int CLEAR_COLOR = 0x2FA8E8;
	/** Seberapa kuat warna jernih menggantikan warna biome (0..1). */
	private static final float CLEAR_MIX = 0.55f;

	private static final Identifier STILL = Identifier.of("minecraft", "block/water_still");
	private static final Identifier FLOWING = Identifier.of("minecraft", "block/water_flow");
	private static final Identifier OVERLAY = Identifier.of("minecraft", "block/water_overlay");

	@Override
	public void onInitializeClient() {
		SimpleFluidRenderHandler handler = new SimpleFluidRenderHandler(STILL, FLOWING, OVERLAY, 0xFFFFFF) {
			@Override
			public int getFluidColor(BlockRenderView view, BlockPos pos, FluidState state) {
				if (view == null || pos == null) {
					return CLEAR_COLOR;
				}
				return mix(BiomeColors.getWaterColor(view, pos), CLEAR_COLOR, CLEAR_MIX);
			}
		};

		FluidRenderHandlerRegistry.INSTANCE.register(Fluids.WATER, Fluids.FLOWING_WATER, handler);
	}

	private static int mix(int a, int b, float t) {
		int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
		int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
		int r = Math.round(ar + (br - ar) * t);
		int g = Math.round(ag + (bg - ag) * t);
		int bl = Math.round(ab + (bb - ab) * t);
		return (r << 16) | (g << 8) | bl;
	}
}
